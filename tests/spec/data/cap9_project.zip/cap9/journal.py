# SHORE journal: replay with `shore run <this file>`.
from shore.project import Project

p = Project()
p.load_geometry('inputs/00_ball.stl')
p.build_topology('cubed_sphere', nk=5, ds=0.05, growth=1.1, ni=9, nj=16)
p.march()
